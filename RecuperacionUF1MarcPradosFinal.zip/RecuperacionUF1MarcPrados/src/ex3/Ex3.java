package ex3;

import java.io.File;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import ex1.Videojoc;

public class Ex3 {

	static String fileXML = "videojocs.xml";
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		try {
			// Metodo que pide datos del usuario
			pideDatos();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		
		
	}
	
	private static void pideDatos() throws ParserConfigurationException, SAXException, IOException, TransformerException {
		// Pedimos los datos del juego
		System.out.println("Introduce el numero del juego: ");
		int numJuego = tryParseInt();
		System.out.println("Introduce el nombre del juego: ");
		String nombreJuego = sc.nextLine();
		System.out.println("Introduce la plataforma: [XBoxOne, PS4, PC]");
		String plataforma = sc.nextLine();
		System.out.println("Introduce el precio del juego: ");
		double precio = tryParseDouble();
		
		Videojoc v = new Videojoc(numJuego, nombreJuego, plataforma, precio);
		
		// Llamamos al metodo que inserta datos:
		insertaDatosXML(v);

	}
	
	private static void insertaDatosXML(Videojoc v) throws ParserConfigurationException, SAXException, IOException, TransformerException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		
		// Cargamos el XML
		Document doc = db.parse(new File(fileXML));
		NodeList plataformas = doc.getElementsByTagName(v.getPlat());
		
		// Si la plataforma introducida existe:
		if(plataformas.getLength() > 0) {
			
			// Recogemos palataforma e insertamos juego
			Element plataforma = (Element) plataformas.item(0);
			Element jocs = (Element)plataforma.getElementsByTagName("jocs").item(0);
			
			Element joc = doc.createElement("joc");
			joc.setAttribute("id", String.valueOf(v.getNum()));
			jocs.appendChild(joc);

			Element nombre = doc.createElement("nombre");
			nombre.setTextContent(v.getName());
			joc.appendChild(nombre);

			Element preuElement = doc.createElement("preu");
			preuElement.setTextContent(String.valueOf(v.getPreu()));
			joc.appendChild(preuElement);
			
			// Escribimos el XML en fichero:
			writeXML(doc);
		}else {
			// Si la plataforma no existe:
			System.out.println("La plataforma no existe.");
		}
	}
	
	public static void writeXML(Document doc) throws TransformerException {
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File("videojocs.xml"));
		transformer.transform(source, result);
		System.out.println("Juego insertado.");
	}
	
	private static int tryParseInt() {
		while(true) {
			try {
				int n = sc.nextInt();
				sc.nextLine();
				return n;
			}catch(InputMismatchException e) {
				System.out.println("Introdueix un numero enter");
				sc.nextLine();
			}
		}

	}
	
	private static double tryParseDouble() {
		while(true) {
			try {
				double n = sc.nextDouble();
				sc.nextLine();
				return n;
			}catch(InputMismatchException e) {
				System.out.println("Introdueix un numero!");
				sc.nextLine();
			}
		}

	}
}
