package ex1;

public class Videojoc {

	/*
	 * N�mero de videojoc: Enter. 
	 * Nom del videojoc: String. 
	 * Plataforma: String.
	 * Preu: N�mero amb 2 decimals. 
	 * M�nim 3 Videojocs en el fitxer.
	 */

	private int num;
	private String name;
	private String plat;
	private double preu;
	
	public Videojoc(int num, String name, String plat, double preu) {
		this.num = num;
		this.name = name;
		this.plat = plat;
		this.preu = preu;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlat() {
		return plat;
	}

	public void setPlat(String plat) {
		this.plat = plat;
	}

	public double getPreu() {
		return preu;
	}

	public void setPreu(double preu) {
		this.preu = preu;
	}
}
