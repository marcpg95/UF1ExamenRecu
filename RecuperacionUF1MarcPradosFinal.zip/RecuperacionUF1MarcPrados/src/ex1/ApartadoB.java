package ex1;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ApartadoB {
	static File f = new File("videojocs.dat");

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		int numVidFitxer;
		System.out.println("Introdueix el n�mero de videojoc a buscar:");
		int numVideojoc = tryParseInt();
		FileInputStream fis = null;
		DataInputStream dis = null;
		RandomAccessFile raf;
		
		try {
			fis = new FileInputStream(f);
			dis = new DataInputStream(fis);
			
			raf = new RandomAccessFile(f, "rw");
			while(true)
			while(dis.available() != 0) {
				numVidFitxer = dis.readInt();
				if(numVidFitxer == numVideojoc) {
					
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	private static void canviaDades(DataInputStream dis, int numVideojoc) throws IOException {
		RandomAccessFile raf = new RandomAccessFile(f, "rw");
		System.out.println("Videojoc trobat: ");
		int lengthNameVideojoc = dis.readInt();
		String nomVideojoc = "";
		for(int i = 0; i < lengthNameVideojoc; i++) {
			nomVideojoc = nomVideojoc + dis.readChar();
		}
		
		int lengthPlatVideojoc = dis.readInt();
		String platVideojoc = "";
		for(int i = 0; i < lengthPlatVideojoc; i++) {
			platVideojoc = platVideojoc + dis.readChar();
		}
		//dis.
		double preu = dis.readDouble();

	}
	
	private static int tryParseInt() {
		while(true) {
			try {
				int n = sc.nextInt();
				sc.nextLine();
				return n;
			}catch(InputMismatchException e) {
				System.out.println("Introdueix un numero enter");
				sc.nextLine();
			}
		}

	}
	
}
