package ex1;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class ApartadoA {
	/*
	 * N�mero de videojoc: Enter. 
	 * Nom del videojoc: String. 
	 * Plataforma: String.
	 * Preu: N�mero amb 2 decimals. 
	 * M�nim 3 Videojocs en el fitxer.
	 */

	static ArrayList<Videojoc> videojuegos = new ArrayList<Videojoc>();
	
	public static void main(String[] args) {
		// Metodo que almacena objetos de videojuegos en el arraylist
		guardaObjetos();
		
		// fichero binario donde lo crearemos
		File f = new File("videojocs.dat");
		try {
			// Objetos necesarios para escribir en binario
			FileOutputStream fos = new FileOutputStream(f);
			DataOutputStream dos = new DataOutputStream(fos);
			
			// Por cada videojuego lo escribimos:
			for(Videojoc v : videojuegos) {
				dos.writeInt(v.getNum());
				
				// Para Strings, debemos informar del length que tendra, para despues poder leerlo correctamente
				dos.writeInt(v.getName().length());
				dos.writeChars(v.getName());
				dos.writeInt(v.getPlat().length());
				dos.writeChars(v.getPlat());
				dos.writeDouble(v.getPreu());
			}
			dos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void guardaObjetos() {
		// Creamos 3 juegos
		Videojoc v1 = new Videojoc(1, "Red Dead Redemption", "XBoxOne", 59.99);
		videojuegos.add(v1);
		Videojoc v2 = new Videojoc(2, "Borderlands", "PC", 29.99);
		videojuegos.add(v2);
		Videojoc v3 = new Videojoc(3, "Final Fantasy VII", "PS4", 69.99);
		videojuegos.add(v3);
		
		
	}
}
