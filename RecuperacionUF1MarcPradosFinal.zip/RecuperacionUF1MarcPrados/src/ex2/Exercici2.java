package ex2;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import ex1.Videojoc;

public class Exercici2 {

	public static void main(String[] args) {
		try {
			// Metodo donde realizamos las acciones de la clase:
			creaXML();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
	}

	private static void creaXML() throws IOException, ParserConfigurationException, TransformerException {
		// Creamos un arraylist donde almacenamos los videojuegos del fichero
		ArrayList<Videojoc> aLV = new ArrayList<Videojoc>();
		Videojoc v;
		// Objetos para leer el fichero
		FileInputStream fis = new FileInputStream("videojocs.dat");
		DataInputStream dis = new DataInputStream(fis);

		// Variables donde almacenamos datos del videojuego
		int numVideojuego;

		int nameLength;
		String name = "";

		int platfLength;
		String platf = "";

		double preu;

		// Objeto para gestionar XMLs
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.newDocument();
		
		// Creamos el elemento raiz del XML
		Element root = doc.createElement("Videoconsolas");
		doc.appendChild(root);
		
		// Leemos los datos del fichero binario y los guardasmos en arrat
		System.out.println("Leyendo datos del fichero binario...");
		while (dis.available() != 0) {
			platf = "";
			name = "";
			numVideojuego = dis.readInt();
			nameLength = dis.readInt();
			for (int i = 0; i < nameLength; i++) {
				name = name + dis.readChar();
			}

			platfLength = dis.readInt();
			for (int i = 0; i < platfLength; i++) {
				platf = platf + dis.readChar();
			}

			preu = dis.readDouble();

			v = new Videojoc(numVideojuego, name, platf, preu);
			aLV.add(v);
		}

		// Filtramos por plataformas el array:
		List<Videojoc> listaPs4 = aLV.stream().filter(videojoc -> videojoc.getPlat().equals("PS4"))
				.collect(Collectors.toList());
		List<Videojoc> listaPc = aLV.stream().filter(videojoc -> videojoc.getPlat().equals("PC"))
				.collect(Collectors.toList());
		List<Videojoc> listaXbox = aLV.stream().filter(videojoc -> videojoc.getPlat().equalsIgnoreCase("XBoxOne"))
				.collect(Collectors.toList());

		
		// Creamos elementos de XBOX
		if (listaXbox.size() > 0) {
			Element xboxElement = doc.createElement("XBoxOne");
			root.appendChild(xboxElement);

			Element jocsXbox = doc.createElement("jocs");
			xboxElement.appendChild(jocsXbox);
			System.out.println("Creando los juegos de xbox...");
			for (Videojoc videojoc : listaXbox) {

				Element joc = doc.createElement("joc");
				joc.setAttribute("id", String.valueOf(videojoc.getNum()));
				jocsXbox.appendChild(joc);

				Element nombre = doc.createElement("nombre");
				nombre.setTextContent(videojoc.getName());
				joc.appendChild(nombre);

				Element preuElement = doc.createElement("preu");
				preuElement.setTextContent(String.valueOf(videojoc.getPreu()));
				joc.appendChild(preuElement);


			}
		}
		
		// Creamos elementos de PC
		if (listaPc.size() > 0) {
			Element pcElement = doc.createElement("PC");
			root.appendChild(pcElement);

			Element jocsPc = doc.createElement("jocs");
			pcElement.appendChild(jocsPc);
			System.out.println("Creando los juegos de PC");
			for (Videojoc videojoc : listaPc) {

				Element joc = doc.createElement("joc");
				joc.setAttribute("id", String.valueOf(videojoc.getNum()));
				jocsPc.appendChild(joc);

				Element nombre = doc.createElement("nombre");
				nombre.setTextContent(videojoc.getName());
				joc.appendChild(nombre);

				Element preuElement = doc.createElement("preu");
				preuElement.setTextContent(String.valueOf(videojoc.getPreu()));
				joc.appendChild(preuElement);


			}

		}

		// Creamos elementos de PS4
		if (listaPs4.size() > 0) {

			Element ps4Element = doc.createElement("PS4");
			root.appendChild(ps4Element);

			Element jocsPs4 = doc.createElement("jocs");
			ps4Element.appendChild(jocsPs4);
			System.out.println("Creando los juegos de PS4");
			for (Videojoc videojoc : listaPs4) {

				Element joc = doc.createElement("joc");
				joc.setAttribute("id", String.valueOf(videojoc.getNum()));
				jocsPs4.appendChild(joc);

				Element nombre = doc.createElement("nombre");
				nombre.setTextContent(videojoc.getName());
				joc.appendChild(nombre);

				Element preuElement = doc.createElement("preu");
				preuElement.setTextContent(String.valueOf(videojoc.getPreu()));
				joc.appendChild(preuElement);

			}

		}
		dis.close();
		writeXML(doc);

	}
	
		public static void writeXML(Document doc) throws TransformerException {
			// Guardamos el XML en fichero
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("videojocs.xml"));
			transformer.transform(source, result);
		}

}
